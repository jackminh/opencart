<?php
// Heading
$_['heading_title'] = '在线客户';

// Text
$_['text_view']     = '显示详细...';
