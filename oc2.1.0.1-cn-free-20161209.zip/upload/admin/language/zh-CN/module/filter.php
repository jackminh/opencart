<?php
// Heading
$_['heading_title']    = '筛选器';

// Text
$_['text_module']         = '筛选器模块';
$_['text_success']        = '成功：: 您已经修改了筛选器模块！';
$_['text_edit']        = '编辑筛选器模块';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission']    = '警告：您没有修改这个模块的权限！';