<?php
// Heading
$_['heading_title']    = '到商店自提';

// Text
$_['text_shipping']    = '配送管理';
$_['text_success']     = '成功：您已修改到商店自提！';
$_['text_edit']        = '编辑到店自提配送';

// Entry
$_['entry_geo_zone']   = '区域群组';
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告您没有权限修改到商店自提！';