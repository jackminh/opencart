<?php
// Heading
$_['heading_title']         = '客户余额统计';

// Column
$_['text_list']             = '客户余额列表';
$_['column_customer']       = '客户名称';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = '用户组';
$_['column_status']         = '状态';
$_['column_credit']         = '客户余额';
$_['column_orders']         = '订单数量';
$_['column_total']          = '金额总计';
$_['column_action']         = '管理';

// Entry
$_['entry_date_start']      = '开始日期';
$_['entry_date_end']        = '结束日期';