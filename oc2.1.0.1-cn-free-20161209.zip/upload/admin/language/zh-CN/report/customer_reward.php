<?php
// Heading
$_['heading_title']         = '客户奖励积分统计';

// Text
$_['text_list']             = '客户奖励积分列表';

// Column
$_['column_customer']       = '客户名称';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = '用户组';
$_['column_status']         = '状态';
$_['column_points']         = '奖励积分';
$_['column_orders']         = '订单号';
$_['column_total']          = '金额总计';
$_['column_action']         = '管理';

// Entry
$_['entry_date_start']      = '开始日期';
$_['entry_date_end']        = '结束日期';