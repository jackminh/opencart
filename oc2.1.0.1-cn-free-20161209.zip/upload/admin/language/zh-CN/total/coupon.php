<?php
// Heading
$_['heading_title']    = '优惠券';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功优惠券更新完成！';
$_['text_edit']        = '编辑优惠券';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告您没有权限修改优惠券！';