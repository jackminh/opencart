<?php
// Heading
$_['heading_title']    = '税率';

// Text
$_['text_total']       = '订单总计';
$_['text_success']     = '成功税率更新完成！';
$_['text_edit']        = '编辑税率';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告您没有变更税率的权限！';