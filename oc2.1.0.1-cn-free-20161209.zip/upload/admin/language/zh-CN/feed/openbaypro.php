<?php
// Heading
$_['heading_title']	  = '大市场平台';

// Text
$_['text_module']    = '模块';
$_['text_installed'] = '大市场平台模块安装完毕。它可以在扩展功能 -> 大市场平台中找到';