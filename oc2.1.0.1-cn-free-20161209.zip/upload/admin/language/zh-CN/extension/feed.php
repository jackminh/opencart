<?php
// Heading
$_['heading_title']      = '插件扩展';

// Text
$_['text_success']     = '成功: 您已经修改了扩展！';
$_['text_list']        = '扩展列表';

// Column
$_['column_name']        = '插件名称';
$_['column_status']      = '状态';
$_['column_action']      = '管理';

// Error
$_['error_permission']   = '警告： 您没有权限修改插件扩展！';