<?php
$_['heading_title']    = '百度流量分析';

// Text
$_['text_analytics']   = '分析';
$_['text_success']	   = '成功：您已经修改了百度流量分析！';
$_['text_edit']        = '编辑 百度流量分析';
$_['text_signup']      = '登陆 <a href="http://tongji.baidu.com/" target="_blank"><u>百度统计</u></a> 注册后获取统计代码';

// Entry
$_['entry_code']       = '百度统计代码';
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告：您还没有权限修改百度流量分析！';
$_['error_code']	     = '统计代码必须填写！';
